object HelloScala extends App{
	println("hello world!");
}
